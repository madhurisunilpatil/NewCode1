package Algorithms;

public class Sorting_Main {
	static void bubble_sort(int a[])
    {
        int i,j,temp;
        for(i=0;i<a.length-1;i++)//passes
        {
            for(j=0;j<a.length-1;j++)//sort
            {
                if(a[j]>a[j+1])//swap
                {
                    temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                }
            }
        }
    }
    static void selection_sort(int a[])
    {
        int i,j,min,pos;
        for(i=0;i<a.length-1;i++)//passes
        {
            min=a[i];pos=i;//ref
            for(j=i+1;j<a.length;j++)
            {
                if(a[j]<min)//update
                {
                    min=a[j];
                    pos=j;
                }
            }
            a[pos]=a[i];
            a[i]=min;
        }
    }

 static void insertion_sort(int a[])
 {
     int i,j,inserted_element;
     for(i=0;i<a.length-1;i++)//passes
     {
         inserted_element=a[i+1];
         j=i+1;
         while(j>0 && a[j-1]>inserted_element)
         {
             a[j]=a[j-1];
             j--;
         }
         a[j]=inserted_element;
     }
 }
    static void quick_sort(int a[],int start,int end)
    {
        int i=start;
        int j=end;
        int pivot=start;
        while(i<j)
        {
            while(a[i]<a[pivot])
                i++;
            while(a[j]>a[pivot])
                j--;
            if(i<j)
            {
                int t=a[i];
                a[i]=a[j];
                a[j]=t;
            }
        }
        if(i<end)
            quick_sort(a,i+1,end);
        if(start<j)
            quick_sort(a,start,j-1);
    }
    static void merger(int a[],int start,int mid,int end) {
        int i = start;
        int j = mid + 1;
        int t[] = new int[a.length];
        int ti = start;//t-index
        while (i <= mid && j <= end)
        {
            if (a[i] < a[j])
                t[ti++] = a[i++];
            else
                t[ti++] = a[j++];
        }
        while (j <= end)//copy leftover
        {
            t[ti++] = a[j++];
        }
        while (i <= mid)//copy leftover
        {
            t[ti++] = a[i++];
        }
        //copy to a
        for(i=start;i<=end;i++)
            a[i]=t[i];
    }

    static void merge_sort(int a[],int start,int end)
    {
        if(start<end)
        {
            int mid=(start+end)/2;
            merge_sort(a,start,mid);
            merge_sort(a,mid+1,end);
            merger(a,start,mid,end);
        }
    }

    public static void main(String args[])
    {
        int a[]={88,11,44,22,99,77,55,66,33};
        System.out.println("Array before sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
        //call to sort
        //Sorting_Main.bubble_sort(a);
        //Sorting_Main.selection_sort(a);
        //Sorting_Main.insertion_sort(a);
        //Sorting_Main.quick_sort(a,0,a.length-1);
        Sorting_Main.merge_sort(a,0,a.length-1);
        System.out.println("\nArray after sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
    }

}
