package Algorithms;

public class selection_sort {
	static void selection_sort(int a[])
    {
        int i,j,min,pos;
        for(i=0;i<a.length-1;i++)//passes
        {
            min=a[i];pos=i;//ref
            for(j=i+1;j<a.length;j++)
            {
                if(a[j]<min)//update
                {
                    min=a[j];
                    pos=j;
                }
            }
            a[pos]=a[i];
            a[i]=min;
        }
    }
	public static void main(String args[]) {
		int a[]={88,11,44,22,99,77,55,66,33};
        System.out.println("Array before sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
        //call to sort
        selection_sort.selection_sort(a);
        System.out.println("\nArray after sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
	}

}
