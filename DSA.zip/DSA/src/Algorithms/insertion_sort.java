package Algorithms;

public class insertion_sort {
	static void insertion_sort(int a[])
	{
	  int i,j,inserted_element;
	  for(i=0;i<a.length-1;i++)//passes
		{
		  inserted_element=a[i+1];
	        j=i+1;
		  while(j>0 && a[j-1]>inserted_element)
			{
			  a[j]=a[j-1];
			  j--;
			}
		a[j]=inserted_element;
		}
	}
	public static void main(String args[]) {
		int a[]={88,11,44,22,99,77,55,66,33};
        System.out.println("Array before sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
        //call to sort
        insertion_sort.insertion_sort(a);
        System.out.println("\nArray after sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
	}


}
