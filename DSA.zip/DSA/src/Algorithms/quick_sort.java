package Algorithms;

public class quick_sort {
	static void quick_sort(int a[],int start,int end)
	{
	  int i=start;
	  int j=end;
	  int pivot=start;
	  while(i<j)
		{
			while(a[i]<a[pivot])
				i++;
			while(a[j]>a[pivot])
				j--;
			if(i<j)
			 {
				int t=a[i];
				a[i]=a[j];
				a[j]=t;
			 }
	     }
		if(i<end)
			quick_sort(a,i+1,end);
		if(start<j)
			quick_sort(a,start,j-1);
	}
	public static void main(String args[]) {
		int a[]={88,11,44,22,99,77,55,66,33};
        System.out.println("Array before sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
        //call to sort
        quick_sort.quick_sort(a,0,a.length-1);
        System.out.println("\nArray after sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
	}

}
