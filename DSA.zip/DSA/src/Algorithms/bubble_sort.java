package Algorithms;

public class bubble_sort {
	 static void bubble_sort(int a[])
	    {
	        int i,j,temp;
	        for(i=0;i<a.length-1;i++)//passes
	        {
	            for(j=0;j<a.length-1;j++)//sort
	            {
	                if(a[j]>a[j+1])//swap
	                {
	                    temp=a[j];
	                    a[j]=a[j+1];
	                    a[j+1]=temp;
	                }
	            }
	        }
	    }
	 public static void main(String args[]){
	    {
	        int a[]={88,11,44,22,99,77,55,66,33};
	        System.out.println("Array before sort:");
	        for (int i=0;i<a.length;i++)
	        {
	            System.out.print(a[i]+",");
	        }
	        //call to sort
	        Sorting_Main.bubble_sort(a);
	        System.out.println("\nArray after sort:");
	        for (int i=0;i<a.length;i++)
	        {
	            System.out.print(a[i]+",");
	        }
	    }
	}



}
