package Algorithms;

public class merge_sort {static void merger(int a[],int start,int mid,int end) {
        int i = start;
        int j = mid + 1;
        int t[] = new int[a.length];
        int ti = start;//t-index
        while (i <= mid && j <= end)
        {
            if (a[i] < a[j])
                t[ti++] = a[i++];
            else
                t[ti++] = a[j++];
        }
        while (j <= end)//copy leftover
        {
            t[ti++] = a[j++];
        }
        while (i <= mid)//copy leftover
        {
            t[ti++] = a[i++];
        }
        //copy to a
        for(i=start;i<=end;i++)
            a[i]=t[i];
    }

    static void merge_sort(int a[],int start,int end)
    {
        if(start<end)
        {
            int mid=(start+end)/2;
            merge_sort(a,start,mid);
            merge_sort(a,mid+1,end);
            merger(a,start,mid,end);
        }
    }

    public static void main(String args[])
    {
        int a[]={88,11,44,22,99,77,55,66,33};
        System.out.println("Array before sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
        //call to sort
        //Sorting_Main.bubble_sort(a);
        //Sorting_Main.selection_sort(a);
        //Sorting_Main.insertion_sort(a);
        //Sorting_Main.quick_sort(a,0,a.length-1);
        merge_sort.merge_sort(a,0,a.length-1);
        System.out.println("\nArray after sort:");
        for (int i=0;i<a.length;i++)
        {
            System.out.print(a[i]+",");
        }
    }

}
