package Assignment;

import Graphs.GraphDemo;

public class CelebrityMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Celebrity c = new Celebrity();
        
        c.createGraph(5);
        c.printG();
        c.findRowsAndColumnsWithSpecificConditions();
    }

}
