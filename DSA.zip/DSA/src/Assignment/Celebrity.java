package Assignment;
import java.util.Scanner;


public class Celebrity {
    int v, visited[], g[][];
    int rowToCheck = 0;
    int columnToCheck=0;
    boolean isAllZero = true;
    boolean isAllcolZero = true;
    boolean isZeroRow = true;
    boolean hasNonZero = false;
    

    void createGraph(int nodes) {
        v = nodes;
        Scanner in = new Scanner(System.in);
        g = new int[v][v]; // adjacency matrix
        visited = new int[v]; // visited array
        for (int i = 0; i < v; i++) {
            for (int j = 0; j < v; j++) {
                System.out.println("Enter value for v" + i + " to v" + j + " (999 for infinity):");
                g[i][j] = in.nextInt();
            }
        }
    }

    void printG() {
        for (int i = 0; i < v; i++) {
            for (int j = 0; j < v; j++) {
                System.out.print(g[i][j] + "\t");
            }
            System.out.println();
        }
    }

    
    void findRowsAndColumnsWithSpecificConditions() {
        System.out.println("Rows and Columns with specific conditions:");

        // Finding rows with all zero values
        System.out.println("Rows with all zero values:");
        boolean isZeroRow = true;
        for (int i = 0; i < v; i++) {
            
            for (int j = 0; j < v; j++) {
                if (g[i][j] != 0) {
                    isZeroRow = false;
                    break;
                }
            }
            if (isZeroRow) {
                System.out.println("Row " + i + " is completely zero.");
            }
        }

        // Finding columns with exactly one `0` and the rest non-zero
        System.out.println("Columns with exactly one `0` and all other entries are non-zero:");
        for (int j = 0; j < v; j++) {
            int countZero = 0;
            boolean hasNonZero = false;

            for (int i = 0; i < v; i++) {
                if (g[i][j] == 0) {
                    countZero++;
                } else if (g[i][j] != 0) {
                    hasNonZero = true;
                }
            }

            // Check if there is exactly one `0` and all other entries are non-zero
            if (countZero == 1 && hasNonZero) {
                System.out.println("Column " + j + " has exactly one `0` and all other entries are non-zero.");
            }
            if(countZero == 1 && hasNonZero && isZeroRow == true) {
            	System.out.println("V"+ j +"is Celebrity");
            }
            
        }
        
        
    }
    
    
}