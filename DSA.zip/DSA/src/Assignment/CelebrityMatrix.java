package Assignment;

public class CelebrityMatrix {
	public static int findCelebrity(boolean[][] matrix) {
        int n = matrix.length;
        int candidate = 0;

        // Finding the candidate using a two-pointer approach
        for (int i = 1; i < n; i++) {
            if (matrix[candidate][i]) {
                candidate = i;
            }
        }

        // Verifying the candidate
        for (int i = 0; i < n; i++) {
            if (i != candidate) {
                // The candidate should not know anyone
                // Everyone should know the candidate
                if (matrix[candidate][i] || !matrix[i][candidate]) {
                    return -1; // No celebrity
                }
            }
        }

        return candidate;
    }

    public static void main(String[] args) {
        // Example matrix for 5 nodes (people)
        // true indicates that the person at row knows the person at column
        boolean[][] matrix = {
            {false, true, true, false, true},  // Person 0 knows 1, 2, and 4
            {false, false, true, false, false}, // Person 1 knows 2
            {false, false, false, false, false}, // Person 2 knows no one
            {false, true, true, false, true},  // Person 3 knows 1, 2, and 4
            {false, false, true, false, false} // Person 4 knows 2
        };

        int celebrity = findCelebrity(matrix);
        if (celebrity == -1) {
            System.out.println("No celebrity found.");
        } else {
            System.out.println("The celebrity is person " + celebrity);
        }
    }

}
