package Queue_Examples;

public class Circular_Queue {
	int front,rear,MaxSize,q[],count;
	void createqueue(int size) 
	{
		front=0;
		rear=-1;
		MaxSize=size;
		q=new int[size];
		count=0;	
	}
	void dequeue(int e)
	{
		rear=(rear+1)%MaxSize;
		count++;
		q [rear]=e;
	}
	boolean isfull()
	{
		if(count==MaxSize) 
			return true;
		else
			return false;	
	}
	int dequeue()
	{
		int temp=q[front];
		front=(front+1)%MaxSize;
		count--;
		return temp;		
	}
	boolean isEmpty()
	{
		if (count==0)
			return true;
		else
			return false;
	}
	void printqueue()
	{
		int i =front;
		int c=0;
		while(c<count)
		{
			System.out.println(q[i]+"----");
			i=(i+1)%MaxSize;
			c++;
		}
	}
}
