package Interview_Problems;
import java.util.Scanner;

public class Stacks_2_in_1 {
	int tos1,tos2,MaxSize,s[];
	
	void create_stack(int size)
	{
		MaxSize=size;
		tos1=-1;
		tos2=size;
		s=new int[size];
	}
	void push1(int e)
	{
		tos1++;
		s[tos1]=e;
	}
	void push2(int e)
	{
		tos2--;
		s[tos2]=e;
	}
	boolean isfull()
	{
		if(tos1==tos2-1)
			return true;
		else 
			return false;
	}
	int pop1()
	{
		int temp=s[tos1];
		tos1--;
		return temp;
	}
	int pop2()
	{
		int temp=s[tos2];
		tos2++;
		return temp;
	}
	int peek1()
	{
		return (s[tos1]);
	}
	int peek2()
	{
		return (s[tos2]);
	}
	boolean is_empty1()
	{
		if (tos1==-1)
			return true;
		else
			return false;
	}
	boolean is_empty_2()
	{
		if(tos2==0)
			return true;
		else
			return false;
	}
	void print_stack1() 
	{
		for(int i=tos1;i>=0;i++)
			System.out.println(s[i]);
	}
	void print_stack2()
	{
		for(int i=tos2;i<MaxSize;i++)
			System.out.println(s[i]);
	}
	public static void main(String[]args)
	{
		Scanner in=new Scanner(System.in);
		Stacks_2_in_1 obj = new Stacks_2_in_1();
		
		int size,choice,element;
		
		System.out.println("Enter the size of stack.");
		size=in.nextInt();
		
		obj.create_stack(size);
		
		do {
			System.out.println("\nMenu:");
            System.out.println("1. Push in Stack 1");
            System.out.println("2. Push in Stack 2");
            System.out.println("3. Pop from Stack 1");
            System.out.println("4. Pop from Stack 2");
            System.out.println("5. Peek in Stack 1");
            System.out.println("6. Peek in Stack 2");
            System.out.println("7. Print Stack 1");
            System.out.println("8. Print Stack 2");
            System.out.println("9. Exit");
            System.out.println("Enter your choice:");
            
            choice=in.nextInt();
            
            switch(choice) 
            {
            case 1:
            	if(obj.isfull()!=true) //not full
            	{
            		System.out.println("Enter data");
            		int e=in.nextInt();
            		obj.push1(e);
            		System.out.println(e+"pushed");
            	}
            	else
            		System.out.println("Stack1 is fulled");
            break;
            
            case 2:
            	if(obj.isfull()!=true) //not full
            	{
            		System.out.println("Enter data");
            		int e=in.nextInt();
            		obj.push2(e);
            		System.out.println(e+"pushed");
            	}
            	else
            		System.out.println("Stack2 is fulled");
            	break;
            	
            case 3:
            	if(obj.is_empty1()!=true) //not empty
            	{
            		System.out.println(obj.pop1()+"popped");
            	}
            	else
            		System.out.println("Stack1 is empty");
            	break;
            case 4:
            	if(obj.is_empty_2()!=true) //not empty
            	{
            		System.out.println(obj.pop2()+"popped");
            	}
            	else
            		System.out.println("Stack2 is empty");
            	break;
            case 5:
            	if(obj.is_empty1()!=true) //not empty
            	{
            		System.out.println(obj.peek1()+"is at peek");
            	}
            	else
            		System.out.println("Stack1 is empty");
            	break;
            case 6:
            	if(obj.is_empty_2()!=true) //not empty
            	{
            		System.out.println(obj.peek2()+"is at peek");
            	}
            	else
            		System.out.println("Stack2 is empty");
            	break; 
            case 7:
            	if(obj.is_empty1()!=true) //not empty
            	{
            		System.out.println("Stack has");
            	}
            	else
            		System.out.println("Stack1 is empty");
            	break; 
            case 8:
            	if(obj.is_empty_2()!=true) //not empty
            	{
            		System.out.println("Stack has");
            	}
            	else
            		System.out.println("Stack2 is empty");
            	break; 
            case 9:
            	System.out.println("Thnaks for using code..");
            	break;
            }
		}while(choice!=0);
	}
}
