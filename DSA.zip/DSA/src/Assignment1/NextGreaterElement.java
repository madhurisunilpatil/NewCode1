package Assignment1;

public class NextGreaterElement {
 
 static void NextGreaterElement(int arr[], int n)
 {
     int next, i, j;
     for (i = 0; i < n; i++) {
         next = -1;
         for (j = i + 1; j < n; j++) {
             if (arr[i] < arr[j]) {
                 next = arr[j];
                 break;
             }
         }
         System.out.println(arr[i] + " -- " + next);
     }
 }

 public static void main(String args[])
 {
     int arr[] = { 4,5,2,10,8 };
     int n = arr.length;
     NextGreaterElement(arr, n);
 }
}
