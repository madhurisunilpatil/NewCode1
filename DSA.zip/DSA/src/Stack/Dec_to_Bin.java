package Stack;
import java.util.Scanner;

public class Dec_to_Bin {
	 public static void main(String args[])
	    {
	        Stack obj=new Stack();
	        Scanner in =new Scanner(System.in);
	        System.out.println("Enter data:");
	        int input=in.nextInt();
	        obj.create_stack(64);
	        while(input!=0)
	        {
	            int remainder=input%2;
	            obj.push(remainder);
	            input=input/2;
	        }

	        System.out.println("Number is Binary is:");
	        while(obj.is_empty()!=true)
	            System.out.print(obj.pop());

	    }

}
