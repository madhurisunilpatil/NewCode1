package Linked_List_Examples;
import java.util.Scanner;

public class Dynamic_Stack
{
    Node tos;
    void create_stack()
    {
        tos=null;//root is never created but assigned to 1st
    }
    void push(int data)
    {
        Node n=new Node(data);
        if(tos==null)//list not created then this is root
            tos=n;
        else
        {
            n.next=tos;//1
            tos=n;//2
        }
        System.out.println(data+" pushed");
    }
    void pop()
    {
        if(tos==null)//list not created then this is root
            System.out.println("Stack empty");
        else
        {
            Node t=tos;//1
            tos=tos.next;//2
            System.out.println(t.data+" poped from stack");
        }
    }
    void peek()
    {
        if(tos==null)//list not created then this is root
            System.out.println("Stack empty");
        else
        {
            System.out.println(tos.data+" is at peek in stack");
        }
    }
    void print_stack()
    {
        if(tos==null)//list not created then this is root
            System.out.println("List empty");
        else
        {
            Node t=tos;
            while(t!=null)
            {
                System.out.println(t.data);
                System.out.println("----");
                t=t.next;
            }
        }
    }
}
 class Dynamic_Stack_Example
{
    public static void main(String args[])
    {
        Dynamic_Stack obj=new Dynamic_Stack();
        Scanner in =new Scanner(System.in);
        obj.create_stack();
        int ch;
        do
        {
            System.out.println("\nStack Menu\n-----------\n1.Push\n2.Pop\n3.Peek\n4.Print\n0.Exit\n:");
            ch=in.nextInt();
            switch (ch)
            {
                case 1:
                        System.out.println("Enter data:");
                        int e=in.nextInt();
                        obj.push(e);
                        break;
                case 2:
                        obj.pop();
                        break;
                case 3:
                        obj.peek();
                        break;
                case 4:
                        obj.print_stack();
                        break;
                case 0:
                    System.out.println("Thanks for using code");
                    break;
                default:
                    System.out.println("Wrong option selected");
                    break;
            }
        }while(ch!=0);//not with exit condition
    }
}
