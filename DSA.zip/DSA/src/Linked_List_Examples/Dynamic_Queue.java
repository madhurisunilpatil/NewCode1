package Linked_List_Examples;

import java.util.Scanner;

import Queue_Examples.Queue;

public class Dynamic_Queue
{
    Node front,rear;
    void create_queue()
    {
        front=rear=null;
    }
    void enqueue(int data)
    {
        Node n=new Node(data);
        if(rear==null)//queue not created
        {front=rear=n;}
        else
        {
            rear.next=n;
            rear=n;
        }
        System.out.println(data+" Enqueued");
    }
    void dequeue()
    {
        if(front==null)//list not created then this is root
            System.out.println("List empty");
        else
        {
            Node t=front;//1
            if(front==rear)
                front=rear=null;//reset both
            else
                front=front.next;//2
            System.out.println(t.data+" dequeued from queue");
        }

    }
    void print_queue()
    {
        if(front==null)//list not created then this is root
            System.out.println("List empty");
        else
        {
            Node t=front;
            while(t!=null)
            {
                System.out.print("-|"+t.data+"|-");
                t=t.next;
            }
        }
    }
}
class Dynamic_Queue_Example
{
    public static void main(String args[])
    {
        int ch;
        Scanner in=new Scanner(System.in);
        Dynamic_Queue obj=new Dynamic_Queue();
        obj.create_queue();//user given size :stack
        do
        {
            System.out.println("\n1.Enqueue\n2.Dequeue\n3.Print\n0.Exit\n:");
            ch=in.nextInt();
            switch(ch)
            {
                case 1:
                    System.out.println("Enter data to insert:");
                    int e=in.nextInt();
                    obj.enqueue(e);
                    break;
                case 2:
                    obj.dequeue();
                    break;
                case 3:
                    System.out.println("Data in queue");
                    obj.print_queue();
                    break;
                case 0:
                    System.out.println("Exiting.....");
                    break;
                default:
                    System.out.println("Wrong option selected");
                    break;
            }
        }while(ch!=0);
    }

}