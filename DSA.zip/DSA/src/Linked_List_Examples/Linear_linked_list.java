package Linked_List_Examples;

public class Linear_linked_list 
{
	
	Node root;
	void create_list()
	{
		root=null; ///root is never created but assigned to 1 st
	}
	void insert_left(int data)
	{
		Node n=new Node(data);
		if(root==null) //List not created then this is root
			root=n;
		else
		{
			n.next=root;//1
			root=n;//2
		}
		System.out.println(data+"inserted in list");
	}
	void delete_left()
	{
		
		if(root==null) //List not created then this is root
			System.out.println("List empty");
		else
		{
			Node t=root;//1
			root=root.next;//2
			System.out.println(t.data+"deleted from list");
		}
		
	}
	void insert_right(int data)
	{
		Node n=new Node(data);
		if(root==null) //List not created then this is root
			root=n;
		else
		{
			Node t=root;//1
			while(t.next!=null)//2
			 root=root.next;
			t.next=n;//3
		}
		System.out.println(data+"inserted in list");
	}
	void delete_right()
	{
		
		if(root==null) //List not created then this is root
			System.out.println("List empty");
		else
		{
			Node t=root;//1
			Node t2=root;
			while(t.next!=null)
			{
				t2=t;//last
				t=t.next;//next
			}
			if(t==root)//only one node
				root=null;//reset root
			else
				t2.next=null;
			
			System.out.println(t.data+"deleted from list");
		}
		
	}
	void print_list()
	{
		if(root==null) //List not created then this is root
			System.out.println("List empty");
		else
		{
			Node t=root;
			while(t!=null)
			{
				System.out.println("|"+t.data+"|");
				t=t.next;
			}
		}
	}
	 void search_list(int key)
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	            Node t=root;
	            while(t!=null)
	            {
	             if(t.data==key)
	             {
	                 System.out.println("Found in list");
	                 break;
	             }
	             t=t.next;
	            }
	            if(t==null)
	                System.out.println("Not found in list");
	        }
	    }
	 void delete_key(int key)
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	            Node t=root;
	            Node t2=root;
	            while(t!=null)
	            {
	                if(t.data==key)
	                {
	                    System.out.println("Found in list");
	                    break;
	                }
	                t2=t;
	                t=t.next;
	            }
	            if(t==null)
	                System.out.println("Not found in list");
	            else //found and check for case
	            {
	                if(t==root)//case 1
	                    root=root.next;
	                else if(t.next==null)//case 2
	                    t2.next=null;
	                else//case 3
	                    t2.next=t.next;
	                System.out.println(t.data+" deleted from list");
	            }
	            }
	        }
	 void insert_at(int index,int data)
     {
         if(root==null)
             System.out.println("List empty");
         else
         {
           if(index==0)
           {
               Node n=new Node(data);
               n.next=root;
               root=n;
           }
           else
           {
             Node t=root;
             Node t2=root;
             int i=0;
             while(t!=null && index>0)
             {
                 t2=t;
                 t=t.next;
                 index--;
             }
             if(t==null)
                 System.out.println("Index out of range");
             else
             {
                 Node n=new Node(data);
                 t2.next=n;
                 n.next=t;
             }
             System.out.println(data+"inserted");
           }
         }

     }

}
