package Linked_List_Examples;

public class Node {
	public static Node left = null;
	public int data;
	public Node next;
	public Node right;
	public Node(int data)
	{
		this.data=data;
		this.next=null;
	}
	

}
