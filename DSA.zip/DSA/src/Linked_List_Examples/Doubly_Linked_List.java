package Linked_List_Examples;

public class Doubly_Linked_List {
	
	    Dnode root;
	    void create_list()
	    {
	        root=null;//root is never created but assigned to 1st
	    }
	    void insert_left(int data)
	    {
	        Dnode n=new Dnode(data);
	        if(root==null)//list not created then this is root
	            root=n;
	        else
	        {
	            root.left=n;//1
	            n.right=root;
	            root=n;//2
	        }
	        System.out.println(data+" inserted in list");
	    }
	    void delete_left()
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	        	Dnode t=root;//1
	            if(root.left==null && root.right==null)
	                root=null;//manual deleted
	            else {
	                root = root.right;//2
	                root.left = null;//3
	            }
	            System.out.println(t.data+" deleted from list");
	        }

	    }
	    void insert_right(int data)
	    {
	        Dnode n=new Dnode(data);
	        if(root==null)//list not created then this is root
	            root=n;
	        else
	        {
	            Dnode t=root;//1
	            while(t.right!=null)//2
	                t=t.right;
	            t.right=n;//3
	            n.left=t;
	            
	            
	        }
	        System.out.println(data+" inserted in list");
	    }
	    void delete_right()
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	            Dnode t=root;//1
	        
	            while(t.right!=null)
	            {
	          
	                t=t.right;//next
	            }
	            if(t==root)//only one Dnode
	                root=null;//reset root
	            else
	            {
	            	Dnode t2=t.left;
	                t2.right=null;
	            }
	            System.out.println(t.data+" deleted from list");
	        }

	    }
	    void print_list()
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	            Dnode t=root;
	            while(t!=null)
	            {
	                System.out.print("|"+t.data+"|->");
	                t=t.right;
	            }
	        }
	    }
	    void rev_print_list()
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	            Dnode t=root;
	            while(t.right!=null)
	            {
	                t=t.right;
	                while(t!=null)
	                {
	                	System.out.print("|"+t.data+"|->");
	                	t=t.left;
	                }
	            }
	        }
	    }
	}
