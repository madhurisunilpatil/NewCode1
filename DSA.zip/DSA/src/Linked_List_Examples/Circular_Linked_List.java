package Linked_List_Examples;

public class Circular_Linked_List {
	
	    Node root,last;
	    void create_list()
	    {
	        root=last=null;
	    }
	    void insert_left(int data)
	    {
	        Node n=new Node(data);
	        if(root==null)//list not created then this is root
	        {
	            root=last=n;
	            last.next=root;
	        }
	        else
	        {
	            n.next=root;//1
	            root=n;//2
	            last.next=root;//3
	        }
	        System.out.println(data+" inserted in list");
	    }
	    void delete_left()
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	            Node t=root;//1
	            if(root==last)
	            {
	                root=last=null;
	            }
	            else {
	                root = root.next;//2
	                last.next = root;//3
	                System.out.println(t.data + " deleted from list");
	            }
	        }

	    }
	    void insert_right(int data)
	    {
	        Node n=new Node(data);
	        if(root==null)//list not created then this is root
	        {
	            root=last=n;
	            last.next=root;
	        }
	        else
	        {
	           last.next=n;//1
	           last=n;//2
	           last.next=root;//3
	        }
	        System.out.println(data+" inserted in list");
	    }
	    void delete_right()
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	            Node t=root;//1
	            Node t2=root;//1
	            while(t.next!=root)//2
	            {
	                t2=t;//last
	                t=t.next;//next
	            }
	            if(t==root)//only one node
	            { root=last=null;}//reset root
	            else
	            {
	                last=t2;//3
	                last.next=root;//4
	            }
	            System.out.println(t.data+" deleted from list");
	        }

	    }
	    void print_list()
	    {
	        if(root==null)//list not created then this is root
	            System.out.println("List empty");
	        else
	        {
	            Node t=root;
	           do
	            {
	                System.out.print("|"+t.data+"|->");
	                t=t.next;
	            } while(t!=root);
	        }
	    }

	}

	
