package Assignment2;
import java.util.Scanner;

public class Student_Main {
	public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        Student_Linked_List studentList = new Student_Linked_List();
        int choice;

        do {
            System.out.println("\nStudent Management System");
            System.out.println("1. Add Student");
            System.out.println("2. Display Students");
            System.out.println("3. Search Student by Roll Number");
            System.out.println("4. Search Student by Partial Roll Number");
            System.out.println("5. Modify Student");
            System.out.println("6. Remove Student");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter roll number: ");
                    int rollNo = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter gender (M/F): ");
                    char gender = scanner.next().charAt(0);
                    studentList.addStudent(rollNo, name, gender);
                    break;

                case 2:
                    studentList.displayStudents();
                    break;

                case 3:
                    System.out.print("Enter roll number to search: ");
                    rollNo = scanner.nextInt();
                    Student student = studentList.searchStudent(rollNo);
                    if (student != null) {
                        System.out.println("Roll No: " + student.rollNo + ", Name: " + student.name + ", Gender: " + student.gender);
                    } else {
                        System.out.println("Student with roll number " + rollNo + " not found.");
                    }
                    break;

                case 4:
                    System.out.print("Enter partial roll number to search: ");
                    rollNo = scanner.nextInt();
                    studentList.searchStudentPartial(rollNo);
                    break;

                case 5:
                    System.out.print("Enter roll number to modify: ");
                    rollNo = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter new gender (M/F): ");
                    gender = scanner.next().charAt(0);
                    studentList.modifyStudent(rollNo, name, gender);
                    break;

                case 6:
                    System.out.print("Enter roll number to remove: ");
                    rollNo = scanner.nextInt();
                    studentList.removeStudent(rollNo);
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 7);

        scanner.close();
    }
}


