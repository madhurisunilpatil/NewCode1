package Assignment2;

public class Student_Linked_List 
{
	Student root;

    public void addStudent(int rollNo, String name, char gender) {
        Student newStudent = new Student(rollNo, name, gender);
        if (root == null) {
            root = newStudent;
        } else {
            Student temp = root;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newStudent;
        }
        System.out.println("Student added successfully.");
    }

    public void displayStudents() {
        if (root == null) {
            System.out.println("No students found.");
        } else {
            Student temp = root;
            while (temp != null) {
                System.out.println("Roll No: " + temp.rollNo + ", Name: " + temp.name + ", Gender: " + temp.gender);
                temp = temp.next;
            }
        }
    }

    public Student searchStudent(int rollNo) {
        Student temp = root;
        while (temp != null) {
            if (temp.rollNo == rollNo) {
                return temp;
            }
            temp = temp.next;
        }
        return null;
    }

    public void searchStudentPartial(int rollNo) {
        boolean found = false;
        Student temp = root;
        while (temp != null) {
            if (String.valueOf(temp.rollNo).contains(String.valueOf(rollNo))) {
                System.out.println("Roll No: " + temp.rollNo + ", Name: " + temp.name + ", Gender: " + temp.gender);
                found = true;
            }
            temp = temp.next;
        }
        if (!found) {
            System.out.println("No student found with partial roll number: " + rollNo);
        }
    }

    public void modifyStudent(int rollNo, String newName, char newGender) {
        Student student = searchStudent(rollNo);
        if (student != null) {
            student.name = newName;
            student.gender = newGender;
            System.out.println("Student record updated successfully.");
        } else {
            System.out.println("Student with roll number " + rollNo + " not found.");
        }
    }

    public void removeStudent(int rollNo) {
        if (root == null) {
            System.out.println("The list is empty.");
            return;
        }

        if (root.rollNo == rollNo) {
            root = root.next;
            System.out.println("Student removed successfully.");
            return;
        }

        Student temp = root;
        while (temp.next != null && temp.next.rollNo != rollNo) {
            temp = temp.next;
        }

        if (temp.next == null) {
            System.out.println("Student with roll number " + rollNo + " not found.");
        } else {
            temp.next = temp.next.next;
            System.out.println("Student removed successfully.");
        }
    }
}


