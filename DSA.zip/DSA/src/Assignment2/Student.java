package Assignment2;

public class Student {
	int rollNo;
    String name;
    char gender;
    Student next;

    public Student(int rollNo, String name, char gender) {
        this.rollNo = rollNo;
        this.name = name;
        this.gender = gender;
        this.next = null;
    }


}
